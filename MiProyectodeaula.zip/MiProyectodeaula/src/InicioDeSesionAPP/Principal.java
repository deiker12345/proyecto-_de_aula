package InicioDeSesionAPP;

/**
 *
 * @author ASUS
 */
public class Principal {
    public static void main(String[] args) {
        Ventana.main(args);
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
